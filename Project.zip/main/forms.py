from django import forms
from .models import Parents

class ParentForm(forms.ModelForm):
    class Meta:
        model = Parents
        fields = ['name', 'email', 'contact','password']
        widgets = {
        'password': forms.PasswordInput(),
    }