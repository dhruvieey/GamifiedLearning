from django.shortcuts import render,redirect
from .models import Parents
from .forms import ParentForm
from django.contrib.auth import authenticate, login
def index(req):
    return render(req, 'main\index.html')

def signin(req):
    return render(req, 'main\signin.html')

def dashboard(req):
    return render(req,'main\dashboard.html')

def add_parent(request):
    if request.method == 'POST':
        form = ParentForm(request.POST)
        if form.is_valid():
            if (request.POST['password'] == request.POST['confirm_password']):
                form.save()
                return redirect('success')
            else:
                return render(request, 'main/add_parent.html', {'form': form},{'error': 'Invalid email or password.'})
    else:
        form = ParentForm()
    return render(request, 'main/add_parent.html', {'form': form})

def success(request):
    return render(request, 'main/index.html')

def verify_parent(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'main/verify_parent.html', {'error': 'Invalid email or password.'})
    else:
        return render(request, 'main/verify_parent.html')
