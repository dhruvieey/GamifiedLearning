from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name='home'),
    path('signin/', views.signin),
    path('dashboard', views.dashboard),
    path('sign_up/', views.add_parent, name='sign_up'),
    path('success/', views.success, name='success'),
]